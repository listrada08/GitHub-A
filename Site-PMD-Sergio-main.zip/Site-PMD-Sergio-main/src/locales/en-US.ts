
export const enUS = {
  // Sidebar
  sidebar: {
    digitalVault: 'Digital Vault',
    investmentTracker: 'Investment Tracker',
    dashboard: 'Dashboard',
    portfolio: 'Portfolio',
    transactions: 'Transactions',
    cryptocurrencies: 'Cryptocurrencies',
    investorProfile: 'Account',
    wallets: 'Wallets',
    settings: 'Settings'
  },
  
  // Dashboard
  dashboard: {
    overview: 'Overview',
    followPerformance: 'Track your performance and assets',
    portfolio: 'Portfolio',
    transactions: 'Transactions',
    cryptocurrencies: 'Cryptocurrencies',
    investorProfile: 'Account',
    wallets: 'Wallets',
    settings: 'Settings',
    digitalVault: 'Digital Vault'
  },
  
  // Settings
  settings: {
    siteLanguage: 'Site Language',
    changeLanguageInterface: 'Change the application interface language',
    currentLanguage: 'Current Language',
    selectLanguage: 'Select language',
    userProfile: 'User Profile',
    managePersonalInfo: 'Manage your personal information',
    name: 'Name',
    fullName: 'Your full name',
    email: 'Email',
    emailPlaceholder: 'your@email.com',
    saveProfile: 'Save Profile',
    notifications: 'Notifications',
    configureNotifications: 'Configure how you want to receive notifications',
    generalNotifications: 'General Notifications',
    portfolioChanges: 'Receive notifications about portfolio changes',
    emailNotifications: 'Email Notifications',
    dailySummary: 'Receive daily summaries by email',
    pushNotifications: 'Push Notifications',
    instantAlerts: 'Instant alerts about major changes',
    otherPreferences: 'Other Preferences',
    customizeAppearance: 'Customize app appearance and behavior',
    language: 'Language',
    currency: 'Currency',
    darkMode: 'Dark Mode',
    enableDarkTheme: 'Enable dark theme',
    autoRefresh: 'Auto Refresh',
    autoRefreshDescription: 'Update data automatically every 5 minutes',
    savePreferences: 'Save Preferences',
    security: 'Security',
    manageAccountSecurity: 'Manage your account security',
    changePassword: 'Change Password',
    twoFactorAuth: 'Setup Two-Factor Authentication',
    disconnectAllDevices: 'Disconnect from All Devices',
    aboutApp: 'About App',
    version: 'Version',
    lastUpdate: 'Last update',
    checkUpdates: 'Check Updates'
  },
  
  // Recent Transactions
  recentTransactions: {
    title: 'Recent Transactions',
    viewAll: 'View All',
    buy: 'Buy',
    sell: 'Sell',
    shares: 'shares',
    today: 'Today',
    yesterday: 'Yesterday'
  },
  
  // Common
  common: {
    save: 'Save',
    cancel: 'Cancel',
    loading: 'Loading...',
    error: 'Error',
    success: 'Success'
  },
  
  // Currencies
  currencies: {
    BRL: 'Brazilian Real (R$)',
    USD: 'US Dollar ($)',
    EUR: 'Euro (€)'
  },
  
  // Languages
  languages: {
    'pt-BR': 'Português (Brasil)',
    'en-US': 'English (US)',
    'es-ES': 'Español'
  }
};
