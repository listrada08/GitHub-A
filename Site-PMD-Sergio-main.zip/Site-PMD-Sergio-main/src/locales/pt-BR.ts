export const ptBR = {
  // Sidebar
  sidebar: {
    digitalVault: 'Digital Vault',
    investmentTracker: 'Investment Tracker',
    dashboard: 'Painel',
    portfolio: 'Portfólio',
    transactions: 'Transações',
    cryptocurrencies: 'Criptomoedas',
    investorProfile: 'Conta',
    wallets: 'Carteiras',
    settings: 'Configurações'
  },
  
  // Dashboard
  dashboard: {
    overview: 'Visão Geral',
    followPerformance: 'Acompanhe seu desempenho e ativos',
    portfolio: 'Portfólio',
    transactions: 'Transações',
    cryptocurrencies: 'Criptomoedas',
    investorProfile: 'Conta',
    wallets: 'Carteiras',
    settings: 'Configurações',
    portfolioTracker: 'Rastreador de Portfólio',
    digitalVault: 'Digital Vault'
  },

  // Authentication
  auth: {
    portfolioTracker: 'Digital Vault',
    digitalVault: 'Digital Vault',
    enterCredentials: 'digite sua senha e email para acessar o site',
    login: 'Entrar',
    signUp: 'Cadastrar',
    email: 'Email',
    password: 'Senha',
    fullName: 'Nome Completo',
    enterEmail: 'Digite seu email',
    enterPassword: 'Digite sua senha',
    choosePassword: 'Escolha uma senha',
    enterFullName: 'Digite seu nome completo',
    signingIn: 'Entrando...',
    signIn: 'Entrar',
    creatingAccount: 'Criando conta...',
    createAccount: 'Criar Conta',
    loginSuccessful: 'Login realizado com sucesso! Redirecionando...',
    accountCreated: 'Conta criada com sucesso! Verifique seu email para confirmar sua conta.',
    emailAlreadyRegistered: 'Este email já está registrado. Tente fazer login.',
    unexpectedError: 'Ocorreu um erro inesperado'
  },
  
  // Settings
  settings: {
    siteLanguage: 'Idioma do Site',
    changeLanguageInterface: 'Altere o idioma da interface do aplicativo',
    currentLanguage: 'Idioma Atual',
    selectLanguage: 'Selecione o idioma',
    userProfile: 'Perfil do Usuário',
    managePersonalInfo: 'Gerencie suas informações pessoais',
    name: 'Nome',
    fullName: 'Seu nome completo',
    email: 'Email',
    emailPlaceholder: 'seu@email.com',
    saveProfile: 'Salvar Perfil',
    notifications: 'Notificações',
    configureNotifications: 'Configure como você deseja receber notificações',
    generalNotifications: 'Notificações Gerais',
    portfolioChanges: 'Receber notificações sobre mudanças no portfólio',
    emailNotifications: 'Notificações por Email',
    dailySummary: 'Recibir resumos diários por email',
    pushNotifications: 'Notificações Push',
    instantAlerts: 'Alertas instantâneos sobre grandes mudanças',
    otherPreferences: 'Outras Preferências',
    customizeAppearance: 'Personalize a aparência e comportamento do app',
    language: 'Idioma',
    currency: 'Moeda',
    darkMode: 'Modo Escuro',
    enableDarkTheme: 'Ativar tema escuro',
    autoRefresh: 'Atualização Automática',
    autoRefreshDescription: 'Atualizar dados automaticamente a cada 5 minutos',
    savePreferences: 'Salvar Preferências',
    security: 'Segurança',
    manageAccountSecurity: 'Gerencie a segurança da sua conta',
    changePassword: 'Alterar Senha',
    twoFactorAuth: 'Configurar Autenticação de Dois Fatores',
    disconnectAllDevices: 'Desconectar de Todos os Dispositivos',
    aboutApp: 'Sobre o App',
    version: 'Versão',
    lastUpdate: 'Última atualização',
    checkUpdates: 'Verificar Atualizações'
  },
  
  // Recent Transactions
  recentTransactions: {
    title: 'Transações Recentes',
    viewAll: 'Ver Todas',
    buy: 'Compra',
    sell: 'Venda',
    shares: 'ações',
    today: 'Hoje',
    yesterday: 'Ontem'
  },
  
  // Common
  common: {
    save: 'Salvar',
    cancel: 'Cancelar',
    loading: 'Carregando...',
    error: 'Erro',
    success: 'Sucesso'
  },
  
  // Currencies
  currencies: {
    BRL: 'Real Brasileiro (R$)',
    USD: 'Dólar Americano ($)',
    EUR: 'Euro (€)'
  },
  
  // Languages
  languages: {
    'pt-BR': 'Português (Brasil)',
    'en-US': 'English (US)',
    'es-ES': 'Español'
  }
};
