
import DashboardStats from './DashboardStats';
import PerformanceChart from './PerformanceChart';
import AllocationChart from './AllocationChart';
import RecentTransactions from './RecentTransactions';

interface Investment {
  id: string;
  name: string;
  symbol: string;
  price: string;
  change: string;
  value: string;
  positive: boolean;
  category: string;
  amount?: number;
}

interface Cryptocurrency {
  id: string;
  name: string;
  symbol: string;
  price: string;
  change: string;
  value: string;
  positive: boolean;
  amount: number;
  category: string;
}

interface OverviewSectionProps {
  investments: Investment[];
  cryptos: Cryptocurrency[];
}

const OverviewSection = ({ investments, cryptos }: OverviewSectionProps) => {
  // Combina investimentos e criptomoedas para o gráfico de alocação
  const allInvestments = [...investments, ...cryptos];

  return (
    <div className="space-y-6">
      {/* Cards de estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Saldo Total</p>
              <p className="text-2xl font-bold text-gray-900">R$ 43.650,75</p>
              <div className="flex items-center mt-2 text-green-600">
                <span className="text-sm font-medium">+12.5%</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Ganhos Hoje</p>
              <p className="text-2xl font-bold text-gray-900">R$ 1.850,75</p>
              <div className="flex items-center mt-2 text-green-600">
                <span className="text-sm font-medium">+5.2%</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Investimentos</p>
              <p className="text-2xl font-bold text-gray-900">R$ 38.500,00</p>
              <div className="flex items-center mt-2 text-green-600">
                <span className="text-sm font-medium">+8.1%</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Rendimento Mensal</p>
              <p className="text-2xl font-bold text-gray-900">R$ 4.250,30</p>
              <div className="flex items-center mt-2 text-green-600">
                <span className="text-sm font-medium">+15.8%</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Gráficos */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <PerformanceChart />
        <AllocationChart investments={allInvestments} />
      </div>
      
      {/* Transações Recentes */}
      <RecentTransactions />
    </div>
  );
};

export default OverviewSection;
