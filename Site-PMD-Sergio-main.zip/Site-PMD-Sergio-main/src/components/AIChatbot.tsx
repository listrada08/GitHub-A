
import { useState, useRef, useEffect } from 'react';
import { Bot, User, Send, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface Message {
  id: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
}

interface AIChatbotProps {
  onClose: () => void;
}

const AIChatbot = ({ onClose }: AIChatbotProps) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'bot',
      content: 'Olá! Sou seu assistente virtual do InvestTracker. Como posso ajudá-lo hoje? Fique à vontade para fazer quantas perguntas quiser!',
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const generateBotResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();
    
    if (lowerMessage.includes('ações') || lowerMessage.includes('investir') || lowerMessage.includes('ação')) {
      return 'Para investir em ações, você pode usar nossa seção de Portfólio para adicionar e acompanhar seus investimentos. Recomendo diversificar sua carteira e sempre fazer análises antes de investir. Precisa de mais detalhes sobre algum aspecto específico?';
    }
    
    if (lowerMessage.includes('cripto') || lowerMessage.includes('bitcoin') || lowerMessage.includes('ethereum')) {
      return 'Na seção de Criptomoedas você pode acompanhar seus investimentos em Bitcoin, Ethereum e outras moedas digitais. Lembre-se que criptomoedas são investimentos de alto risco. Quer saber como adicionar uma cripto específica?';
    }
    
    if (lowerMessage.includes('carteira') || lowerMessage.includes('portfolio') || lowerMessage.includes('portfólio')) {
      return 'Sua carteira mostra todos os seus investimentos organizados por categoria. Você pode visualizar o desempenho total e individual de cada ativo na seção "Carteiras". Precisa de ajuda para interpretar algum gráfico?';
    }
    
    if (lowerMessage.includes('configuração') || lowerMessage.includes('configurar') || lowerMessage.includes('configurações')) {
      return 'Nas Configurações você pode personalizar sua moeda preferida, notificações e outras preferências do sistema. Acesse através do menu lateral. Qual configuração específica você gostaria de alterar?';
    }
    
    if (lowerMessage.includes('transação') || lowerMessage.includes('histórico') || lowerMessage.includes('compra') || lowerMessage.includes('venda')) {
      return 'Na seção de Transações você pode ver todo o histórico de compras e vendas dos seus investimentos, com filtros por data e tipo de operação. Precisa de ajuda para encontrar uma transação específica?';
    }
    
    if (lowerMessage.includes('ajuda') || lowerMessage.includes('suporte') || lowerMessage.includes('problema')) {
      return 'Estou aqui para ajudar! Você também pode entrar em contato conosco por email (suporte@investtracker.com) ou telefone (0800-123-4567) durante o horário comercial. Qual é sua dúvida específica?';
    }

    if (lowerMessage.includes('gráfico') || lowerMessage.includes('desempenho') || lowerMessage.includes('rentabilidade')) {
      return 'Os gráficos de desempenho mostram a evolução dos seus investimentos ao longo do tempo. Você pode filtrar por período e comparar diferentes ativos. Quer entender melhor algum indicador específico?';
    }

    if (lowerMessage.includes('renda fixa') || lowerMessage.includes('tesouro') || lowerMessage.includes('cdb')) {
      return 'Para investimentos em renda fixa como Tesouro Direto e CDBs, você pode cadastrá-los na seção de Portfólio. Eles oferecem mais segurança mas geralmente menor rentabilidade. Precisa de dicas sobre diversificação?';
    }

    if (lowerMessage.includes('obrigado') || lowerMessage.includes('valeu') || lowerMessage.includes('vlw')) {
      return 'Por nada! Fico feliz em ajudar. Se tiver mais dúvidas sobre seus investimentos ou como usar o InvestTracker, estarei aqui. Qual sua próxima pergunta?';
    }
    
    return 'Entendo sua pergunta. Para questões mais específicas, recomendo entrar em contato com nossa equipe de suporte especializada. Posso ajudar com informações sobre como usar o InvestTracker! Tem alguma outra dúvida que posso esclarecer?';
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: inputValue,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Simular delay de resposta da IA
    setTimeout(() => {
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        content: generateBotResponse(inputValue),
        timestamp: new Date()
      };

      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 800 + Math.random() * 800);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <Card className="w-80 h-96 flex flex-col shadow-lg">
      <CardHeader className="pb-3 flex-shrink-0">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <Bot className="w-5 h-5 text-blue-600" />
            Assistente IA
          </CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="h-6 w-6 p-0"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
        <p className="text-xs text-gray-500">
          Faça quantas perguntas quiser!
        </p>
      </CardHeader>
      
      <CardContent className="flex-1 flex flex-col p-3 gap-3">
        {/* Área de mensagens */}
        <div className="flex-1 overflow-y-auto space-y-3 min-h-0 scroll-smooth">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[85%] rounded-lg p-2.5 text-sm leading-relaxed ${
                  message.type === 'user'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-900 border border-gray-200'
                }`}
              >
                <div className="flex items-start gap-2">
                  {message.type === 'bot' && (
                    <Bot className="w-4 h-4 mt-0.5 text-blue-600 flex-shrink-0" />
                  )}
                  {message.type === 'user' && (
                    <User className="w-4 h-4 mt-0.5 text-white flex-shrink-0" />
                  )}
                  <span className="break-words">{message.content}</span>
                </div>
                <div className={`text-xs mt-1 ${
                  message.type === 'user' ? 'text-blue-100' : 'text-gray-400'
                }`}>
                  {message.timestamp.toLocaleTimeString('pt-BR', { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                  })}
                </div>
              </div>
            </div>
          ))}
          
          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-gray-100 border border-gray-200 rounded-lg p-2.5 text-sm">
                <div className="flex items-center gap-2">
                  <Bot className="w-4 h-4 text-blue-600" />
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse delay-100"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse delay-200"></div>
                  </div>
                  <span className="text-gray-500">digitando...</span>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Campo de entrada */}
        <div className="flex gap-2 flex-shrink-0 pt-2 border-t border-gray-200">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Digite sua pergunta..."
            className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            disabled={isTyping}
          />
          <Button
            onClick={handleSendMessage}
            disabled={!inputValue.trim() || isTyping}
            size="sm"
            className="px-3 bg-blue-600 hover:bg-blue-700"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default AIChatbot;
