
import { useState } from 'react';
import { HelpCircle, MessageSquare, Phone, Mail, X, ChevronUp, Bot } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import AIChatbot from './AIChatbot';

const SupportTab = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [showAIChat, setShowAIChat] = useState(false);

  const supportOptions = [
    {
      icon: Bot,
      title: 'Assistente IA',
      description: 'Chat inteligente para ajuda imediata',
      action: () => setShowAIChat(true)
    },
    {
      icon: MessageSquare,
      title: 'Chat ao Vivo',
      description: 'Converse conosco em tempo real',
      action: () => console.log('Abrindo chat ao vivo')
    },
    {
      icon: Mail,
      title: 'Email',
      description: 'Envie-nos um email',
      action: () => window.open('mailto:suporte@investtracker.com')
    },
    {
      icon: Phone,
      title: 'Telefone',
      description: 'Ligue para nossa central',
      action: () => console.log('Abrindo discador: 0800-123-4567')
    }
  ];

  return (
    <div className="fixed bottom-4 left-4 z-50">
      {/* Chatbot IA */}
      {showAIChat && (
        <div className="mb-2">
          <AIChatbot onClose={() => setShowAIChat(false)} />
        </div>
      )}

      {/* Painel de suporte expandido */}
      {isOpen && !showAIChat && (
        <Card className="mb-2 w-80 shadow-lg">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Central de Suporte</CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsOpen(false)}
                className="h-6 w-6 p-0"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-gray-600 mb-4">
              Como podemos ajudá-lo hoje?
            </p>
            
            {supportOptions.map((option, index) => {
              const Icon = option.icon;
              return (
                <Button
                  key={index}
                  variant="outline"
                  className="w-full justify-start h-auto p-3"
                  onClick={option.action}
                >
                  <div className="flex items-start gap-3">
                    <Icon className={`w-5 h-5 mt-0.5 ${
                      option.icon === Bot ? 'text-purple-600' : 'text-blue-600'
                    }`} />
                    <div className="text-left">
                      <div className="font-medium">{option.title}</div>
                      <div className="text-sm text-gray-500">{option.description}</div>
                    </div>
                  </div>
                </Button>
              );
            })}
            
            <div className="pt-2 border-t">
              <p className="text-xs text-gray-500 text-center">
                Horário de atendimento: Seg-Sex, 8h às 18h
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Botão flutuante de suporte */}
      {!showAIChat && (
        <Button
          onClick={() => setIsOpen(!isOpen)}
          className="rounded-full w-12 h-12 bg-blue-600 hover:bg-blue-700 shadow-lg"
          size="sm"
        >
          {isOpen ? (
            <ChevronUp className="w-5 h-5 text-white" />
          ) : (
            <HelpCircle className="w-5 h-5 text-white" />
          )}
        </Button>
      )}
    </div>
  );
};

export default SupportTab;
