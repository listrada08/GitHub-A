
import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Progress } from './ui/progress';
import { CheckCircle2, AlertCircle, TrendingUp, Shield, Target } from 'lucide-react';

interface Question {
  id: number;
  question: string;
  options: { text: string; score: number }[];
}

const InvestorProfileSection = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [showResult, setShowResult] = useState(false);
  const [profileResult, setProfileResult] = useState<string>('');

  const questions: Question[] = [
    {
      id: 1,
      question: "Qual é a sua experiência com investimentos?",
      options: [
        { text: "Sou iniciante, tenho pouca ou nenhuma experiência", score: 1 },
        { text: "Tenho alguma experiência, já investi algumas vezes", score: 2 },
        { text: "Tenho experiência moderada, invisto regularmente", score: 3 },
        { text: "Sou experiente, invisto há vários anos", score: 4 },
        { text: "Sou muito experiente, trabalho na área financeira", score: 5 }
      ]
    },
    {
      id: 2,
      question: "Por quanto tempo você pretende manter seus investimentos?",
      options: [
        { text: "Menos de 1 ano", score: 1 },
        { text: "1 a 3 anos", score: 2 },
        { text: "3 a 5 anos", score: 3 },
        { text: "5 a 10 anos", score: 4 },
        { text: "Mais de 10 anos", score: 5 }
      ]
    },
    {
      id: 3,
      question: "Como você reagiria se seus investimentos perdessem 20% do valor em um mês?",
      options: [
        { text: "Venderia tudo imediatamente", score: 1 },
        { text: "Ficaria muito preocupado e consideraria vender", score: 2 },
        { text: "Ficaria preocupado mas manteria os investimentos", score: 3 },
        { text: "Manteria os investimentos sem me preocupar muito", score: 4 },
        { text: "Aproveitaria para comprar mais", score: 5 }
      ]
    },
    {
      id: 4,
      question: "Qual é o seu principal objetivo com os investimentos?",
      options: [
        { text: "Preservar o capital (não perder dinheiro)", score: 1 },
        { text: "Gerar uma renda extra segura", score: 2 },
        { text: "Equilibrar segurança e crescimento", score: 3 },
        { text: "Fazer o dinheiro crescer moderadamente", score: 4 },
        { text: "Maximizar os ganhos, mesmo com mais risco", score: 5 }
      ]
    },
    {
      id: 5,
      question: "Que porcentagem da sua renda você pode investir?",
      options: [
        { text: "Menos de 5%", score: 1 },
        { text: "5% a 10%", score: 2 },
        { text: "10% a 20%", score: 3 },
        { text: "20% a 30%", score: 4 },
        { text: "Mais de 30%", score: 5 }
      ]
    }
  ];

  const handleAnswer = (score: number) => {
    const newAnswers = [...answers, score];
    setAnswers(newAnswers);

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      calculateProfile(newAnswers);
    }
  };

  const calculateProfile = (allAnswers: number[]) => {
    const totalScore = allAnswers.reduce((sum, score) => sum + score, 0);
    const averageScore = totalScore / allAnswers.length;

    let profile = '';
    let description = '';
    let recommendations = '';

    if (averageScore <= 2) {
      profile = 'Conservador';
      description = 'Você prefere investimentos seguros e estáveis, priorizando a preservação do capital sobre grandes retornos.';
      recommendations = 'Recomendamos: Poupança, CDB, Tesouro Direto (Selic e Prefixado), Fundos DI.';
    } else if (averageScore <= 3) {
      profile = 'Moderado';
      description = 'Você busca um equilíbrio entre segurança e rentabilidade, aceitando alguns riscos por melhores retornos.';
      recommendations = 'Recomendamos: Tesouro IPCA+, CDB com rentabilidade maior, Fundos Multimercado conservadores, até 20% em ações.';
    } else if (averageScore <= 4) {
      profile = 'Moderado Arrojado';
      description = 'Você está disposto a assumir riscos moderados em busca de retornos mais expressivos no longo prazo.';
      recommendations = 'Recomendamos: Mix de renda fixa e variável (30-50% ações), Fundos de Ações, ETFs, Fundos Imobiliários.';
    } else {
      profile = 'Arrojado';
      description = 'Você tem alta tolerância ao risco e busca maximizar retornos, mesmo com maior volatilidade.';
      recommendations = 'Recomendamos: Ações individuais, ETFs internacionais, Fundos de Ações, Criptomoedas (pequena %), REITs.';
    }

    setProfileResult(`${profile}|${description}|${recommendations}`);
    setShowResult(true);
  };

  const resetTest = () => {
    setCurrentQuestion(0);
    setAnswers([]);
    setShowResult(false);
    setProfileResult('');
  };

  const getProfileIcon = (profile: string) => {
    switch (profile) {
      case 'Conservador':
        return <Shield className="w-8 h-8 text-blue-600" />;
      case 'Moderado':
        return <Target className="w-8 h-8 text-green-600" />;
      case 'Moderado Arrojado':
        return <TrendingUp className="w-8 h-8 text-orange-600" />;
      case 'Arrojado':
        return <AlertCircle className="w-8 h-8 text-red-600" />;
      default:
        return <CheckCircle2 className="w-8 h-8 text-gray-600" />;
    }
  };

  const getProfileColor = (profile: string) => {
    switch (profile) {
      case 'Conservador':
        return 'bg-blue-50 border-blue-200';
      case 'Moderado':
        return 'bg-green-50 border-green-200';
      case 'Moderado Arrojado':
        return 'bg-orange-50 border-orange-200';
      case 'Arrojado':
        return 'bg-red-50 border-red-200';
      default:
        return 'bg-gray-50 border-gray-200';
    }
  };

  if (showResult) {
    const [profile, description, recommendations] = profileResult.split('|');
    
    return (
      <div className="space-y-6">
        <Card className={`${getProfileColor(profile)}`}>
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              {getProfileIcon(profile)}
            </div>
            <CardTitle className="text-2xl">Seu Perfil: {profile}</CardTitle>
            <CardDescription className="text-lg">{description}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold mb-3">Recomendações para você:</h3>
              <p className="text-gray-700">{recommendations}</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-white rounded-lg">
                <div className="text-2xl font-bold text-gray-900">
                  {Math.round((answers.reduce((sum, score) => sum + score, 0) / answers.length) * 20)}%
                </div>
                <div className="text-sm text-gray-500">Tolerância ao Risco</div>
              </div>
              
              <div className="text-center p-4 bg-white rounded-lg">
                <div className="text-2xl font-bold text-gray-900">{answers.length}</div>
                <div className="text-sm text-gray-500">Perguntas Respondidas</div>
              </div>
              
              <div className="text-center p-4 bg-white rounded-lg">
                <div className="text-2xl font-bold text-gray-900">
                  {profile === 'Conservador' ? '1-3' : 
                   profile === 'Moderado' ? '3-5' :
                   profile === 'Moderado Arrojado' ? '5-10' : '10+'}
                </div>
                <div className="text-sm text-gray-500">Anos Recomendados</div>
              </div>
            </div>
            
            <div className="flex justify-center">
              <Button onClick={resetTest} variant="outline">
                Refazer Teste
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Descubra seu Perfil de Investidor</CardTitle>
          <CardDescription>
            Responda algumas perguntas para descobrir qual tipo de investidor você é e receber recomendações personalizadas.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <div className="flex justify-between text-sm text-gray-600">
              <span>Pergunta {currentQuestion + 1} de {questions.length}</span>
              <span>{Math.round(((currentQuestion) / questions.length) * 100)}% concluído</span>
            </div>
            <Progress value={(currentQuestion / questions.length) * 100} className="h-2" />
          </div>
          
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">{questions[currentQuestion].question}</h3>
            
            <div className="space-y-3">
              {questions[currentQuestion].options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => handleAnswer(option.score)}
                  className="w-full p-4 text-left border border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-colors"
                >
                  {option.text}
                </button>
              ))}
            </div>
          </div>
          
          {currentQuestion > 0 && (
            <div className="flex justify-center">
              <Button 
                variant="outline" 
                onClick={() => setCurrentQuestion(Math.max(0, currentQuestion - 1))}
              >
                Voltar
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default InvestorProfileSection;
