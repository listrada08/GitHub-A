
import React, { createContext, useContext, useState, useEffect } from 'react';

interface PreferencesContextType {
  currency: string;
  setCurrency: (currency: string) => void;
  darkMode: boolean;
  setDarkMode: (darkMode: boolean) => void;
  language: string;
  setLanguage: (language: string) => void;
  formatCurrency: (value: number) => string;
}

const PreferencesContext = createContext<PreferencesContextType | undefined>(undefined);

export const usePreferences = () => {
  const context = useContext(PreferencesContext);
  if (!context) {
    throw new Error('usePreferences must be used within a PreferencesProvider');
  }
  return context;
};

export const PreferencesProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currency, setCurrency] = useState(() => {
    return localStorage.getItem('currency') || 'BRL';
  });
  
  const [darkMode, setDarkMode] = useState(() => {
    return localStorage.getItem('darkMode') === 'true';
  });
  
  const [language, setLanguage] = useState(() => {
    return localStorage.getItem('language') || 'pt-BR';
  });

  // Apply dark mode to document
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('darkMode', darkMode.toString());
  }, [darkMode]);

  // Save currency to localStorage
  useEffect(() => {
    localStorage.setItem('currency', currency);
  }, [currency]);

  // Save language to localStorage
  useEffect(() => {
    localStorage.setItem('language', language);
  }, [language]);

  const formatCurrency = (value: number): string => {
    const formatters = {
      BRL: new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
      }),
      USD: new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
      }),
      EUR: new Intl.NumberFormat('de-DE', {
        style: 'currency',
        currency: 'EUR'
      })
    };

    const formatter = formatters[currency as keyof typeof formatters] || formatters.BRL;
    return formatter.format(value);
  };

  const value = {
    currency,
    setCurrency,
    darkMode,
    setDarkMode,
    language,
    setLanguage,
    formatCurrency
  };

  return (
    <PreferencesContext.Provider value={value}>
      {children}
    </PreferencesContext.Provider>
  );
};
